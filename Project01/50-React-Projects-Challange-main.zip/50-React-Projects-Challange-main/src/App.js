import ExpandingCards from "./Project-1/Expanding-Cards";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <ExpandingCards />
    </div>
  );
}
